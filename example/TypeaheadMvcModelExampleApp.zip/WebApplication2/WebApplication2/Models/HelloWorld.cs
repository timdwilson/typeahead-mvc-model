﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class HelloWorld
    {
        public int HelloWorldId { get; set; }
        public string Message { get; set; }
        public string Name { get; set; }
        public int PersonId { get; set; }
    }
}